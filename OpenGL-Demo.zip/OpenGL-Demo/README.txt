Camera Controls

Right-Click: Hold to enable camera controls
W: Move Forward
A: Move Left
S: Move Backward
D: Move Right


Gui Controls:

Mouse Senesitivity: Adjust mouse sensitivity
Post-Processing: Slide to enable different post-processing effects
Light Options: Edit values to change the light colors and specular and ambient strength
Emitter Options: Edit values to change information about the Particle emitter including the colors the particles start and end with, the minimum and maximum velocites they can have, and the maximum amount of particles on screen at any given time
Mesh Options: Change the Maximum height and the amount of separation of the verticies on the mesh